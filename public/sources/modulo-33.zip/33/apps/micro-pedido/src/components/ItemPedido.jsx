export default function ItemPedido({ item, aoRemover }) {
  return <li><div><strong>{item.nome}</strong><small>{item.quantidade}x · R$ {(item.preco * item.quantidade).toFixed(2).replace('.', ',')}</small></div><button aria-label={`Remover ${item.nome}`} onClick={() => aoRemover(item.id)}>×</button></li>;
}
