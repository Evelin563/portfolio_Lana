import React from 'react'; import { createRoot } from 'react-dom/client'; import Pedido from './Pedido'; import './styles.css';
createRoot(document.getElementById('root')).render(<Pedido />);
