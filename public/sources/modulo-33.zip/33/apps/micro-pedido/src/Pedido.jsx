import { useEffect, useMemo, useState } from 'react';
import ItemPedido from './components/ItemPedido';
import './styles.css';

export default function Pedido() {
  const [itens, setItens] = useState([]);
  useEffect(() => {
    const incluir = ({ detail: prato }) => setItens((atuais) => {
      const encontrado = atuais.find((item) => item.id === prato.id);
      return encontrado ? atuais.map((item) => item.id === prato.id ? { ...item, quantidade: item.quantidade + 1 } : item) : [...atuais, { ...prato, quantidade: 1 }];
    });
    window.addEventListener('pedido:adicionar', incluir);
    return () => window.removeEventListener('pedido:adicionar', incluir);
  }, []);
  const remover = (id) => setItens((atuais) => atuais.filter((item) => item.id !== id));
  const total = useMemo(() => itens.reduce((soma, item) => soma + item.preco * item.quantidade, 0), [itens]);
  // Não retornamos o resultado de dispatchEvent: useEffect só pode retornar uma função de limpeza.
  useEffect(() => {
    window.dispatchEvent(new CustomEvent('pedido:atualizado', { detail: { quantidade: itens.reduce((s, i) => s + i.quantidade, 0) } }));
  }, [itens]);
  return <aside className="micro-pedido"><header><span>Seu pedido</span><h2>Resumo</h2></header>{itens.length === 0 ? <p className="vazio">Seu pedido ainda está vazio.</p> : <><ul>{itens.map((item) => <ItemPedido key={item.id} item={item} aoRemover={remover} />)}</ul><footer><span>Total</span><strong>R$ {total.toFixed(2).replace('.', ',')}</strong></footer></>}</aside>;
}
