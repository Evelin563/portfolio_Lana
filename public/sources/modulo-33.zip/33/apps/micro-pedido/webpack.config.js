const HtmlWebpackPlugin = require('html-webpack-plugin');
const { ModuleFederationPlugin } = require('webpack').container;
module.exports = {
  entry: './src/index.js', output: { publicPath: 'auto', clean: true }, devServer: { port: 3002, historyApiFallback: true },
  resolve: { extensions: ['.js', '.jsx'] }, module: { rules: [{ test: /\.jsx?$/, exclude: /node_modules/, use: 'babel-loader' }, { test: /\.css$/, use: ['style-loader', 'css-loader'] }] },
  plugins: [new ModuleFederationPlugin({ name: 'pedido', filename: 'remoteEntry.js', exposes: { './Pedido': './src/Pedido' }, shared: { react: { singleton: true, requiredVersion: false }, 'react-dom': { singleton: true, requiredVersion: false } } }), new HtmlWebpackPlugin({ template: './public/index.html' })]
};
