import { lazy, Suspense, useEffect, useState } from 'react';
const Cardapio = lazy(() => import('cardapio/Cardapio'));
const Pedido = lazy(() => import('pedido/Pedido'));
const Carregando = () => <p className="carregando">Carregando micro frontend…</p>;

export default function App() {
  const [quantidade, setQuantidade] = useState(0);
  useEffect(() => { const atualizar = ({ detail }) => setQuantidade(detail.quantidade); window.addEventListener('pedido:atualizado', atualizar); return () => window.removeEventListener('pedido:atualizado', atualizar); }, []);
  return <main><header className="topo"><div><span>Micro Frontends</span><h1>Sabores da Casa</h1></div><div className="contador">Pedido <b>{quantidade}</b></div></header><div className="conteudo"><Suspense fallback={<Carregando />}><Cardapio /></Suspense><div className="painel-pedido"><Suspense fallback={<Carregando />}><Pedido /></Suspense></div></div></main>;
}
