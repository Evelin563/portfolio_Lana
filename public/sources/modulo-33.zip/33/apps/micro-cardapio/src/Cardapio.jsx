import PratoCard from './components/PratoCard';
import { pratos } from './data/pratos';
import './styles.css';

export default function Cardapio() {
  // O evento é o contrato público entre este micro e quem consome o pedido.
  const adicionarAoPedido = (prato) => window.dispatchEvent(new CustomEvent('pedido:adicionar', { detail: prato }));
  const salgados = pratos.filter((prato) => prato.categoria === 'salgados');
  const sobremesas = pratos.filter((prato) => prato.categoria === 'sobremesas');
  return <section className="micro-cardapio"><header><span>Cardápio</span><h2>Sabores preparados para você</h2></header><section className="categoria"><div className="titulo-categoria"><span>Pratos principais</span><h3>Experiências salgadas</h3><p>Receitas marcantes para cada momento.</p></div><div className="lista-pratos">{salgados.map((prato) => <PratoCard key={prato.id} prato={prato} aoAdicionar={adicionarAoPedido} />)}</div></section><section className="categoria"><div className="titulo-categoria"><span>Final feliz</span><h3>Doces momentos</h3><p>Uma seleção especial para adoçar o seu pedido.</p></div><div className="lista-pratos">{sobremesas.map((prato) => <PratoCard key={prato.id} prato={prato} aoAdicionar={adicionarAoPedido} />)}</div></section></section>;
}
