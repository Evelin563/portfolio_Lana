export default function PratoCard({ prato, aoAdicionar }) {
  return <article className="prato-card">
    <img src={prato.imagem} alt={prato.nome} loading="lazy" />
    <div><h3>{prato.nome}</h3><p>{prato.descricao}</p></div>
    <footer><strong>R$ {prato.preco.toFixed(2).replace('.', ',')}</strong><button onClick={() => aoAdicionar(prato)}>Adicionar ao pedido</button></footer>
  </article>;
}
