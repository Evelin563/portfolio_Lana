# Módulo 33 - Cardápio

Projeto de estudo de **Micro Frontends** usando React e Webpack 5 Module Federation. O monorepo possui três aplicações que podem evoluir e executar de forma independente.

## Aplicações

| Aplicação | Porta | Responsabilidade |
| --- | ---: | --- |
| `container-app` | 3000 | Orquestra a experiência e carrega os micros remotos. |
| `micro-cardapio` | 3001 | Exibe os pratos e emite a intenção de adicioná-los ao pedido. |
| `micro-pedido` | 3002 | Mantém e apresenta os itens do pedido. |

## Como executar

Pré-requisito: Node.js 18 ou superior.

```bash
npm install
```

Em três terminais diferentes, na raiz do projeto:

```bash
npm run start:cardapio
npm run start:pedido
npm run start:container
```

Abra `http://localhost:3000`. Os dois remotes precisam estar em execução antes de abrir o container. Cada micro também pode ser aberto isoladamente nas portas 3001 e 3002.

Para validar os bundles de produção:

```bash
npm run build
```

## Module Federation

Os micros expõem seus componentes principais no `ModuleFederationPlugin`:

- `cardapio/Cardapio`
- `pedido/Pedido`

O container declara ambos como `remotes` e os carrega com `React.lazy` e `Suspense`. React e ReactDOM são dependências compartilhadas como singleton para evitar múltiplas instâncias do React na página.

## Comunicação entre micros

O `micro-cardapio` não conhece o `micro-pedido`. Ao clicar em **Adicionar ao pedido**, ele dispara o evento global `pedido:adicionar` com o prato em `event.detail`. O `micro-pedido` escuta esse evento, adiciona o prato ao próprio estado local e atualiza as quantidades. Ao remover um item, ele emite `pedido:atualizado`, que o container usa para atualizar o contador do cabeçalho.

Essa fronteira baseada em eventos mantém os micros desacoplados e permite que cada um seja desenvolvido e publicado separadamente.
