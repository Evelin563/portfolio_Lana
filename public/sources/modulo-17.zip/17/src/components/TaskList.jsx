import { memo } from 'react'

function TaskList({ tasks, onToggleTask, onRemoveTask }) {
  return (
    <section>
      <h2>Minhas tarefas</h2>

      {tasks.length === 0 ? (
        <p>Nenhuma tarefa adicionada ainda.</p>
      ) : (
        <ul>
          {tasks.map((task) => (
            <li key={task.id}>
              <span
                style={{
                  textDecoration: task.completed ? 'line-through' : 'none',
                }}
              >
                {task.name}
              </span>

              <button onClick={() => onToggleTask(task.id)}>
                {task.completed ? 'Desfazer' : 'Concluir'}
              </button>

              <button onClick={() => onRemoveTask(task.id)}>
                Remover
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}

export default memo(TaskList)