function TaskFilter({ filter, onChangeFilter }) {
  return (
    <section>
      <button
        onClick={() => onChangeFilter('all')}
        disabled={filter === 'all'}
      >
        Todas
      </button>

      <button
        onClick={() => onChangeFilter('completed')}
        disabled={filter === 'completed'}
      >
        Concluídas
      </button>

      <button
        onClick={() => onChangeFilter('pending')}
        disabled={filter === 'pending'}
      >
        Pendentes
      </button>
    </section>
  )
}

export default TaskFilter