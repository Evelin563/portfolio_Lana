import { createContext, useContext, useMemo, useState } from 'react'
import useLocalStorage from '../hooks/useLocalStorage'

const TaskContext = createContext()

export function TaskProvider({ children }) {
  const [tasks, setTasks] = useLocalStorage('tasks', [])
  const [filter, setFilter] = useState('all')

  function addTask(taskName) {
    const newTask = {
      id: Date.now(),
      name: taskName,
      completed: false,
    }

    setTasks([...tasks, newTask])
  }

  function toggleTask(taskId) {
    const updatedTasks = tasks.map((task) => {
      if (task.id === taskId) {
        return {
          ...task,
          completed: !task.completed,
        }
      }

      return task
    })

    setTasks(updatedTasks)
  }

  function removeTask(taskId) {
    const updatedTasks = tasks.filter((task) => task.id !== taskId)

    setTasks(updatedTasks)
  }

  const filteredTasks = useMemo(() => {
    if (filter === 'completed') {
      return tasks.filter((task) => task.completed)
    }

    if (filter === 'pending') {
      return tasks.filter((task) => !task.completed)
    }

    return tasks
  }, [tasks, filter])

  return (
    <TaskContext.Provider
      value={{
        tasks,
        filter,
        filteredTasks,
        addTask,
        toggleTask,
        removeTask,
        setFilter,
      }}
    >
      {children}
    </TaskContext.Provider>
  )
}

export function useTasks() {
  return useContext(TaskContext)
}