import TaskForm from './components/TaskForm'
import TaskList from './components/TaskList'
import TaskFilter from './components/TaskFilter'
import { useTasks } from './context/TaskContext'

function App() {
  const {
    filteredTasks,
    filter,
    addTask,
    toggleTask,
    removeTask,
    setFilter,
  } = useTasks()

  return (
    <main>
      <h1>Minha Lista de Tarefas</h1>

      <TaskForm onAddTask={addTask} />

      <TaskFilter
        filter={filter}
        onChangeFilter={setFilter}
      />

      <TaskList
        tasks={filteredTasks}
        onToggleTask={toggleTask}
        onRemoveTask={removeTask}
      />
    </main>
  )
}

export default App