# Todo List React

Aplicação de lista de tarefas desenvolvida com React.

O usuário pode adicionar tarefas, marcar como concluídas, desfazer a conclusão, remover tarefas e filtrar entre todas, concluídas e pendentes.

## Tecnologias utilizadas

- React
- Vite
- JavaScript
- CSS
- Context API
- Hooks do React: `useState`, `useEffect`, `useContext` e `useMemo`
- Hook customizado: `useLocalStorage`
- `React.memo`
- localStorage

## Como rodar o projeto localmente

1. Clone o repositório:

```bash
git clone https://github.com/Evelin563/todo-list-react.git