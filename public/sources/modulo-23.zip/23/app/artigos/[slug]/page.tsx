import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import Arte from '@/components/Arte';
import { getArtigos, getArtigo, formatarData, tempoLeitura } from '@/lib/artigos';
import { siteUrl } from '@/lib/site';

export const dynamic = 'force-static';
export const dynamicParams = false;
type Props = { params: Promise<{ slug: string }> };
export async function generateStaticParams() { return (await getArtigos()).map(({ slug }) => ({ slug })); }
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const artigo = await getArtigo((await params).slug);
  if (!artigo) notFound();
  return { title: artigo.titulo, description: artigo.descricao, authors: [{ name: artigo.autor }], alternates: { canonical: `/artigos/${artigo.slug}` }, openGraph: { type: 'article', locale: 'pt_BR', title: artigo.titulo, description: artigo.descricao, publishedTime: artigo.data, authors: [artigo.autor], url: `/artigos/${artigo.slug}` }, twitter: { card: 'summary', title: artigo.titulo, description: artigo.descricao } };
}
export default async function ArtigoPage({ params }: Props) {
  const artigo = await getArtigo((await params).slug);
  if (!artigo) notFound();
  const relacionados = (await getArtigos()).filter(item => item.slug !== artigo.slug).slice(0, 2);
  const schema = { '@context': 'https://schema.org', '@type': 'BlogPosting', headline: artigo.titulo, description: artigo.descricao, datePublished: artigo.data, author: { '@type': 'Person', name: artigo.autor }, mainEntityOfPage: `${siteUrl}/artigos/${artigo.slug}` };
  return <main id="conteudo" className="container article-page"><Link href="/#artigos" className="text-link">← Todos os artigos</Link><article><header className="article-header"><div className="tags"><span className="tag">{artigo.categoria}</span><span>{tempoLeitura(artigo)} min de leitura</span></div><h1>{artigo.titulo}</h1><p className="lead">{artigo.descricao}</p><p className="article-author">Por <strong>{artigo.autor}</strong> <span>·</span> <time dateTime={artigo.data}>{formatarData(artigo.data)}</time></p></header><Arte cor={artigo.cor} destaque/><div className="prose">{artigo.conteudo.map(parte => <section key={parte.titulo}><h2>{parte.titulo}</h2><p>{parte.texto}</p></section>)}</div></article><aside className="related"><h2>Continue a leitura</h2><div>{relacionados.map(item => <Link href={`/artigos/${item.slug}`} key={item.slug}><span className="eyebrow">{item.categoria}</span><h3>{item.titulo} ↗</h3></Link>)}</div></aside><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema).replace(/</g, '\\u003c') }}/></main>;
}
