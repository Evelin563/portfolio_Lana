import type { MetadataRoute } from 'next';
import { getArtigos } from '@/lib/artigos';
import { siteUrl } from '@/lib/site';
export default async function sitemap(): Promise<MetadataRoute.Sitemap> { return [{ url: siteUrl }, ...(await getArtigos()).map(artigo => ({ url: `${siteUrl}/artigos/${artigo.slug}`, lastModified: artigo.data }))]; }
