import type { Metadata } from 'next';
import Link from 'next/link';
import { siteUrl } from '@/lib/site';
import './globals.css';

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: { default: 'Entrelinhas | Leituras do dia a dia', template: '%s | Entrelinhas' },
  description: 'Textos sobre criatividade, design e tecnologia para ler no seu tempo.'
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><body>
    <a className="skip" href="#conteudo">Pular para o conteúdo</a>
    <header className="header container"><Link className="brand" href="/" aria-label="Entrelinhas, página inicial"><span className="brand-icon">e.</span>entrelinhas</Link><nav aria-label="Navegação principal"><Link href="/#artigos">Explorar artigos <span aria-hidden="true">↗</span></Link></nav></header>
    {children}
    <footer className="container footer"><Link className="brand" href="/">entrelinhas</Link><p>Criatividade, design e cotidiano.</p><span>Entrelinhas © 2026</span></footer>
  </body></html>;
}
