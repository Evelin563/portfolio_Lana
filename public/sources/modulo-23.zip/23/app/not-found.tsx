import Link from 'next/link';
export default function NotFound() { return <main id="conteudo" className="container not-found"><p className="eyebrow">404 · PÁGINA NÃO ENCONTRADA</p><h1>Essa ideia ainda<br/>não está por aqui.</h1><p>O endereço pode estar incorreto ou o artigo não está disponível.</p><Link href="/" className="text-link">← Explorar os artigos</Link></main>; }
