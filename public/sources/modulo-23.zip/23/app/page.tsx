import type { Metadata } from 'next';
import Link from 'next/link';
import Arte from '@/components/Arte';
import { getArtigos, formatarData, tempoLeitura } from '@/lib/artigos';

export const dynamic = 'force-static';
export const metadata: Metadata = { title: 'Entrelinhas | Leituras do dia a dia', description: 'Textos sobre criatividade, design e tecnologia para ler no seu tempo.', alternates: { canonical: '/' } };

export default async function Home() {
  const [destaque, ...artigos] = await getArtigos();
  return <main id="conteudo" className="container">
    <section className="hero"><p className="eyebrow"><span/> CRIATIVIDADE, DESIGN E COTIDIANO</p><h1>Uma pausa<br/>para <em>ler.</em></h1><p className="hero-description">Pegue um café e fique à vontade.<br/>Por aqui, a conversa é sobre ideias, trabalho e as coisas do dia a dia.</p><a className="text-link" href="#artigos">Ver os artigos <span aria-hidden="true">↓</span></a></section>
    <section aria-label="Artigo em destaque"><Link href={`/artigos/${destaque.slug}`} className="featured"><Arte cor={destaque.cor} destaque/><div className="featured-copy"><p className="eyebrow">LEITURA EM DESTAQUE</p><div className="tags"><span className="tag">{destaque.categoria}</span><span>{tempoLeitura(destaque)} min de leitura</span></div><h2>{destaque.titulo}</h2><p>{destaque.descricao}</p><div className="byline"><span className="avatar">CM</span><span>{destaque.autor}<small><time dateTime={destaque.data}>{formatarData(destaque.data)}</time></small></span><span className="circle-arrow" aria-hidden="true">↗</span></div></div></Link></section>
    <section id="artigos" className="articles"><div className="section-heading"><div><p className="eyebrow">NO BLOG</p><h2>Outras leituras</h2></div><span className="count">{artigos.length.toString().padStart(2, '0')} ARTIGOS</span></div><div className="grid">{artigos.map(artigo => <article key={artigo.slug}><Link className="card" href={`/artigos/${artigo.slug}`}><Arte cor={artigo.cor}/><div className="card-body"><div className="tags"><span className="tag">{artigo.categoria}</span><span>{tempoLeitura(artigo)} min de leitura</span></div><h3>{artigo.titulo} <span aria-hidden="true">↗</span></h3><p>{artigo.descricao}</p><div className="card-meta"><span>{artigo.autor}</span><time dateTime={artigo.data}>{formatarData(artigo.data)}</time></div></div></Link></article>)}</div></section>
    <aside className="closing"><p>Leia no seu tempo.<br/><em>A casa é sua.</em></p><a href="#conteudo" className="text-link">Voltar ao início ↑</a></aside>
  </main>;
}
