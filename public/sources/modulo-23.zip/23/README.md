# Módulo 23 - Blog dinâmico

Blog Entrelinhas, desenvolvido com Next.js 15, React 19 e TypeScript.

## Executar

Requer Node.js 20 ou superior e npm.

```sh
npm install
npm run dev
```

Abra http://localhost:3000. Para validar a versão de produção:

```sh
npm run build
npm run typecheck
npm start
```

## Requisitos implementados

- `app/page.tsx`: listagem em Server Component assíncrono.
- `app/artigos/[slug]/page.tsx`: artigo completo com título, autor, data e conteúdo.
- `data/artigos.json`: fonte local de quatro artigos; `lib/artigos.ts` centraliza o acesso assíncrono.
- `force-static` e `generateStaticParams`: páginas geradas no build. Alterações no JSON exigem novo build/deploy.
- `generateMetadata`: título, descrição, autor, canonical, Open Graph e Twitter por artigo.
- `params` assíncrono compatível com Next.js 15.
- Slugs legíveis definidos no JSON, sem biblioteca adicional.
- Página 404 e `dynamicParams = false` para artigos inexistentes.
- Sitemap, robots.txt e dados estruturados BlogPosting.
- Layout responsivo, navegação por teclado e link para pular ao conteúdo.
- Nenhuma busca com useEffect; páginas são Server Components.

## Editar os artigos

Adicione um objeto em `data/artigos.json` com slug único, titulo, descricao, autor, data (AAAA-MM-DD), categoria, cor e conteudo. O conteúdo é uma lista de objetos com titulo e texto. Capas disponíveis: chuva, janela, caderno e mesa. Paleta: #B0E0E6, #87CEEB, #E0F6FF e #F0FFFF, com detalhes em bege.

## Deploy direto na Vercel, sem GitHub

Na pasta do projeto, execute:

```sh
npx vercel login
npx vercel --prod
```

Escolha a conta, crie um projeto chamado `modulo-23-blog-dinamico` e mantenha a detecção automática de Next.js. Nenhum repositório Git é necessário.

Para domínio personalizado, configure `NEXT_PUBLIC_SITE_URL` com a URL pública completa e faça outro deploy. Na Vercel, o domínio de produção é obtido automaticamente de `VERCEL_PROJECT_PRODUCTION_URL`. Localmente, o endereço padrão é http://localhost:3000.

Aplicação publicada: https://modulo-23-blog-dinamico.vercel.app



## Referências

- https://nextjs.org/docs/15/app/api-reference/functions/generate-metadata
- https://nextjs.org/docs/15/app/api-reference/functions/generate-static-params

As capas usam fotografias do Unsplash, carregadas com otimização de imagens do Next.js. Fontes: https://unsplash.com/s/photos/study-table e https://unsplash.com/photos/macbook-pro-on-white-table-QbVvcO6lr2o. Os endereços das fotos estão em components/Arte.tsx. As fontes possuem alternativas locais caso a conexão esteja indisponível.

