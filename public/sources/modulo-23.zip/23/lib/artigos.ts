import 'server-only';
import { cache } from 'react';
import dados from '@/data/artigos.json';

export const getArtigos = cache(async () => [...dados].sort((a, b) => b.data.localeCompare(a.data)));
export const getArtigo = cache(async (slug: string) => (await getArtigos()).find((artigo) => artigo.slug === slug));
export type Artigo = (typeof dados)[number];
export function formatarData(data: string) {
  return new Intl.DateTimeFormat('pt-BR', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(`${data}T12:00:00Z`));
}
export function tempoLeitura(artigo: Artigo) {
  return Math.max(1, Math.ceil(artigo.conteudo.map((parte) => `${parte.titulo} ${parte.texto}`).join(' ').split(/\s+/).length / 200));
}
