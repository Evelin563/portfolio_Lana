import Image from 'next/image';

const fotos: Record<string, { id: string; alt: string }> = {
  chuva: { id: '1534040385115-33dcb3acba5b', alt: 'Café, caderno aberto e uma planta junto à janela.' },
  janela: { id: '1526572195979-0f8a7ea44489', alt: 'Mesa clara com notebook, bloco de notas e uma planta.' },
  caderno: { id: '1743796055651-41c743ff2465', alt: 'Pessoa escrevendo no caderno enquanto consulta o notebook.' },
  mesa: { id: '1529071242804-840f9a164b8b', alt: 'Notebook e material de leitura em uma mesa branca.' },
};

export default function Arte({ cor, destaque = false }: { cor: string; destaque?: boolean }) {
  const foto = fotos[cor] ?? fotos.chuva;
  return <div className={`arte ${cor} ${destaque ? 'arte-destaque' : ''}`}>
    <Image src={`https://images.unsplash.com/photo-${foto.id}?auto=format&fit=crop&w=1400&q=85`} alt={foto.alt} fill sizes={destaque ? '(max-width: 600px) 100vw, 60vw' : '(max-width: 600px) 100vw, 33vw'} priority={destaque} style={{ objectFit: 'cover' }} />
    <span className="photo-credit">Foto: Unsplash</span>
  </div>;
}
