import PainelDeTarefas from '@/components/PainelDeTarefas';
import { buscarTarefas } from '@/data/tarefas';

/** Server Component: carrega os dados antes de entregar a interface ao cliente. */
export default async function Page() {
  const tarefas = await buscarTarefas();

  return (
    <main>
      <PainelDeTarefas tarefasIniciais={tarefas} />
      <footer>Feito para aprender Next.js, React e testes unitários ✿</footer>
    </main>
  );
}
