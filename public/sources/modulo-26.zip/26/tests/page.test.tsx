import { render, screen } from '@testing-library/react';
import Page from '@/app/page';

describe('Página inicial', () => {
  it('renderiza as tarefas carregadas pelo Server Component', async () => {
    render(await Page());
    expect(screen.getByRole('heading', { name: 'Tarefas da semana' })).toBeInTheDocument();
    expect(screen.getByText('Revisar os conceitos de Server Components')).toBeInTheDocument();
    expect(screen.getByText('Escrever o primeiro teste unitário')).toBeInTheDocument();
    expect(screen.getByLabelText('3 tarefas')).toBeInTheDocument();
  });
});
