import type { NextConfig } from 'next';

const isGitHubPages = process.env.GITHUB_ACTIONS === 'true';

const nextConfig: NextConfig = {
  // Gera arquivos estáticos que podem ser publicados pelo GitHub Pages.
  output: 'export',
  // O repositório é publicado em um subcaminho no GitHub Pages.
  basePath: isGitHubPages ? '/Listagem-CI-CD' : '',
};

export default nextConfig;
