# Módulo 30 — CI/CD com Next.js 15

Projeto prático de uma lista de tarefas com **Next.js 15**, App Router, TypeScript, Jest e Testing Library.

## Site publicado

Após o primeiro push na branch `main`, a aplicação será publicada em:

https://evelin563.github.io/Listagem-CI-CD/

## Funcionalidades

- `app/page.tsx` é um Server Component e busca tarefas de um arquivo local assíncrono.
- `components/NovaTarefa.tsx` é um Client Component com formulário controlado e validação.
- `hooks/useContadorDeTarefas.ts` retorna a quantidade atual de tarefas.
- O painel atualiza a lista e o contador sem recarregar a página.

## Executar localmente

```bash
npm install
npm run dev
```

Abra `http://localhost:3000`.

## Testes

```bash
npm test
npm run test:coverage
```

Os testes cobrem o formulário `NovaTarefa`, o hook isolado com `renderHook` e a renderização da página com as tarefas locais, sem mock de API externa.

## Integração contínua e deploy

O workflow em `.github/workflows/main.yml` é acionado em `push` e `pull request` para `main`. Ele instala as dependências com `npm ci`, executa lint, testes e build. Em pushes para `main`, o build estático é publicado automaticamente no GitHub Pages usando o `GITHUB_TOKEN` temporário do GitHub Actions.
