# Entrelinhas — Catálogo de Livros

Aplicação React com TypeScript para cadastrar, listar, atualizar e remover livros por meio da API real do [CrudCrud](https://crudcrud.com).

## Funcionalidades

- Listagem de livros com `GET`
- Cadastro de título, autor e status com `POST`
- Remoção de livros com `DELETE`
- Atualização do status “Lido”/“Não lido” com `PUT`
- Estados de carregamento, envio, atualização e remoção
- Tratamento de erros da API
- Layout responsivo e acessível
- Tipagem estrita de livros, propriedades, estados e eventos

## Organização

```text
src/
├── components/
│   ├── BookForm.tsx
│   ├── BookItem.tsx
│   └── BookList.tsx
├── services/
│   └── bookService.ts
├── types/
│   └── book.ts
├── App.tsx
├── main.tsx
└── styles.css
```

## Configuração da API

1. Acesse [crudcrud.com](https://crudcrud.com) e copie a URL única exibida.
2. Na raiz do projeto, copie `.env.example` para um novo arquivo chamado `.env`.
3. Substitua a URL de exemplo pela sua URL e acrescente o recurso `/livros`:

```env
VITE_API_URL=https://crudcrud.com/api/SEU_ENDPOINT_UNICO/livros
```

> O endpoint gratuito do CrudCrud expira após 24 horas e possui limite de requisições. Gere uma nova URL caso receba erro 404.

## Executar localmente

É necessário ter o Node.js instalado.

```bash
npm install
npm run dev
```

Abra o endereço exibido pelo Vite, normalmente `http://localhost:5173`.

## Verificar o projeto

```bash
npm run lint
npm run build
```

## Publicar no GitHub

Crie um repositório público vazio no GitHub e execute:

```bash
git init
git add .
git commit -m "feat: cria catálogo de livros com React e TypeScript"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/catalogo-de-livros.git
git push -u origin main
```

Não envie o arquivo `.env` ao GitHub. O `.gitignore` já o protege.

## Tecnologias

React, TypeScript, Vite, Axios, Lucide React e CSS.
