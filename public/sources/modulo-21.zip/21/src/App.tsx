import { useCallback, useEffect, useMemo, useState } from 'react'
import axios from 'axios'
import { BookHeart, RefreshCw } from 'lucide-react'
import { BookForm } from './components/BookForm'
import { BookList } from './components/BookList'
import { bookService } from './services/bookService'
import type { Book, NewBook } from './types/book'

function getErrorMessage(error: unknown): string {
  if (axios.isAxiosError(error)) {
    if (error.response?.status === 404) {
      return 'O endpoint não foi encontrado. Gere uma nova URL no CrudCrud e atualize o arquivo .env.'
    }

    if (error.response?.status === 429) {
      return 'O limite de requisições do CrudCrud foi atingido.'
    }

    return 'Não foi possível acessar a API. Verifique sua conexão e tente novamente.'
  }

  return error instanceof Error ? error.message : 'Ocorreu um erro inesperado.'
}

export default function App() {
  const [books, setBooks] = useState<Book[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [removingId, setRemovingId] = useState<string | null>(null)
  const [updatingId, setUpdatingId] = useState<string | null>(null)
  const [error, setError] = useState('')

  const loadBooks = useCallback(async () => {
    try {
      setIsLoading(true)
      setError('')
      setBooks(await bookService.list())
    } catch (requestError) {
      setError(getErrorMessage(requestError))
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    void loadBooks()
  }, [loadBooks])

  async function handleAddBook(newBook: NewBook) {
    try {
      setIsSubmitting(true)
      setError('')
      const createdBook = await bookService.create(newBook)
      setBooks((current) => [createdBook, ...current])
    } catch (requestError) {
      setError(getErrorMessage(requestError))
    } finally {
      setIsSubmitting(false)
    }
  }

  async function handleRemoveBook(id: string) {
    try {
      setRemovingId(id)
      setError('')
      await bookService.remove(id)
      setBooks((current) => current.filter((book) => book._id !== id))
    } catch (requestError) {
      setError(getErrorMessage(requestError))
    } finally {
      setRemovingId(null)
    }
  }

  async function handleToggleStatus(book: Book) {
    try {
      setUpdatingId(book._id)
      setError('')
      const updatedBook = await bookService.updateStatus(book)
      setBooks((current) =>
        current.map((item) => (item._id === book._id ? updatedBook : item)),
      )
    } catch (requestError) {
      setError(getErrorMessage(requestError))
    } finally {
      setUpdatingId(null)
    }
  }

  const readCount = useMemo(
    () => books.filter((book) => book.status === 'Lido').length,
    [books],
  )

  return (
    <main>
      <header className="hero">
        <nav className="brand" aria-label="Identidade da aplicação">
          <span className="brand-icon">
            <BookHeart size={22} aria-hidden="true" />
          </span>
          <span>Entrelinhas</span>
        </nav>

        <div className="hero-copy">
          <span className="eyebrow">Seu catálogo pessoal</span>
          <h1>Livros são lugares para onde sempre podemos voltar.</h1>
          <p>
            Organize suas leituras, celebre cada página concluída e mantenha
            próximas as histórias que ainda esperam por você.
          </p>
        </div>

        <div className="stats" aria-label="Resumo do catálogo">
          <div>
            <strong>{books.length}</strong>
            <span>{books.length === 1 ? 'livro' : 'livros'}</span>
          </div>
          <div>
            <strong>{readCount}</strong>
            <span>{readCount === 1 ? 'leitura concluída' : 'leituras concluídas'}</span>
          </div>
          <div>
            <strong>{books.length - readCount}</strong>
            <span>na lista de desejos</span>
          </div>
        </div>
      </header>

      <div className="page-grid">
        <BookForm onAddBook={handleAddBook} isSubmitting={isSubmitting} />

        <section className="shelf" aria-labelledby="shelf-title">
          <div className="shelf-heading">
            <div>
              <span className="eyebrow">Minha coleção</span>
              <h2 id="shelf-title">Estante de livros</h2>
            </div>
            <button
              className="refresh-button"
              type="button"
              onClick={() => void loadBooks()}
              disabled={isLoading}
            >
              <RefreshCw size={17} className={isLoading ? 'spin' : ''} />
              Atualizar
            </button>
          </div>

          {error && (
            <div className="error-message" role="alert">
              <p>{error}</p>
              <button type="button" onClick={() => void loadBooks()}>
                Tentar novamente
              </button>
            </div>
          )}

          {isLoading ? (
            <div className="loading" role="status">
              <span className="loader" />
              <p>Organizando sua estante...</p>
            </div>
          ) : (
            <BookList
              books={books}
              onRemove={handleRemoveBook}
              onToggleStatus={handleToggleStatus}
              removingId={removingId}
              updatingId={updatingId}
            />
          )}
        </section>
      </div>

      <footer>Desenvolvido com React, TypeScript e curiosidade.</footer>
    </main>
  )
}
