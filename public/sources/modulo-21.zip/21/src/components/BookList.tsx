import { LibraryBig } from 'lucide-react'
import type { Book } from '../types/book'
import { BookItem } from './BookItem'

interface BookListProps {
  books: Book[]
  onRemove: (id: string) => Promise<void>
  onToggleStatus: (book: Book) => Promise<void>
  removingId: string | null
  updatingId: string | null
}

export function BookList({
  books,
  onRemove,
  onToggleStatus,
  removingId,
  updatingId,
}: BookListProps) {
  if (books.length === 0) {
    return (
      <div className="empty-state">
        <LibraryBig size={40} aria-hidden="true" />
        <h3>Sua estante ainda está vazia</h3>
        <p>Adicione o primeiro livro e comece a construir seu catálogo.</p>
      </div>
    )
  }

  return (
    <div className="book-list" aria-live="polite">
      {books.map((book) => (
        <BookItem
          key={book._id}
          book={book}
          onRemove={onRemove}
          onToggleStatus={onToggleStatus}
          isRemoving={removingId === book._id}
          isUpdating={updatingId === book._id}
        />
      ))}
    </div>
  )
}
