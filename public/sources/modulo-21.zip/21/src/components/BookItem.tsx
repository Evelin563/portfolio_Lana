import { BookOpenCheck, Circle, Trash2 } from 'lucide-react'
import type { Book } from '../types/book'

interface BookItemProps {
  book: Book
  onRemove: (id: string) => Promise<void>
  onToggleStatus: (book: Book) => Promise<void>
  isRemoving: boolean
  isUpdating: boolean
}

export function BookItem({
  book,
  onRemove,
  onToggleStatus,
  isRemoving,
  isUpdating,
}: BookItemProps) {
  const isRead = book.status === 'Lido'

  return (
    <article className="book-card">
      <div className={`book-mark ${isRead ? 'read' : ''}`} aria-hidden="true">
        {isRead ? <BookOpenCheck size={24} /> : <Circle size={22} />}
      </div>

      <div className="book-content">
        <span className={`status ${isRead ? 'read' : 'unread'}`}>
          {book.status}
        </span>
        <h3>{book.title}</h3>
        <p>por {book.author}</p>
      </div>

      <div className="book-actions">
        <button
          className="secondary-button"
          type="button"
          onClick={() => void onToggleStatus(book)}
          disabled={isUpdating || isRemoving}
          aria-label={`Marcar ${book.title} como ${isRead ? 'não lido' : 'lido'}`}
        >
          {isUpdating ? 'Atualizando...' : isRead ? 'Marcar não lido' : 'Marcar lido'}
        </button>
        <button
          className="icon-button"
          type="button"
          onClick={() => void onRemove(book._id)}
          disabled={isRemoving || isUpdating}
          aria-label={`Remover ${book.title}`}
          title="Remover livro"
        >
          <Trash2 size={19} aria-hidden="true" />
        </button>
      </div>
    </article>
  )
}
