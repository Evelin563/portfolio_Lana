import { useState, type ChangeEvent, type FormEvent } from 'react'
import { BookPlus } from 'lucide-react'
import type { BookStatus, NewBook } from '../types/book'

interface BookFormProps {
  onAddBook: (book: NewBook) => Promise<void>
  isSubmitting: boolean
}

interface BookFormState {
  title: string
  author: string
  status: BookStatus
}

const initialForm: BookFormState = {
  title: '',
  author: '',
  status: 'Não lido',
}

export function BookForm({ onAddBook, isSubmitting }: BookFormProps) {
  const [form, setForm] = useState<BookFormState>(initialForm)
  const [validationError, setValidationError] = useState('')

  function handleChange(
    event: ChangeEvent<HTMLInputElement | HTMLSelectElement>,
  ) {
    const { name, value } = event.target
    setForm((current) => ({ ...current, [name]: value }))
    setValidationError('')
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()

    const title = form.title.trim()
    const author = form.author.trim()

    if (!title || !author) {
      setValidationError('Preencha o título e o autor do livro.')
      return
    }

    await onAddBook({ title, author, status: form.status })
    setForm(initialForm)
  }

  return (
    <section className="form-card" aria-labelledby="form-title">
      <div className="section-heading">
        <span className="eyebrow">Nova leitura</span>
        <h2 id="form-title">Adicione um livro</h2>
        <p>Registre as histórias que já passaram — ou ainda passarão — por você.</p>
      </div>

      <form onSubmit={handleSubmit}>
        <label htmlFor="title">Título</label>
        <input
          id="title"
          name="title"
          value={form.title}
          onChange={handleChange}
          placeholder="Ex.: A hora da estrela"
          maxLength={120}
          disabled={isSubmitting}
        />

        <label htmlFor="author">Autor(a)</label>
        <input
          id="author"
          name="author"
          value={form.author}
          onChange={handleChange}
          placeholder="Ex.: Clarice Lispector"
          maxLength={100}
          disabled={isSubmitting}
        />

        <label htmlFor="status">Status de leitura</label>
        <select
          id="status"
          name="status"
          value={form.status}
          onChange={handleChange}
          disabled={isSubmitting}
        >
          <option value="Não lido">Não lido</option>
          <option value="Lido">Lido</option>
        </select>

        {validationError && (
          <p className="field-error" role="alert">
            {validationError}
          </p>
        )}

        <button className="primary-button" type="submit" disabled={isSubmitting}>
          <BookPlus size={19} aria-hidden="true" />
          {isSubmitting ? 'Adicionando...' : 'Adicionar à estante'}
        </button>
      </form>
    </section>
  )
}
