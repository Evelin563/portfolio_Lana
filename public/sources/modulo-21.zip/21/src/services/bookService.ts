import axios from 'axios'
import type { Book, NewBook } from '../types/book'

const API_URL = import.meta.env.VITE_API_URL?.trim()

function ensureApiUrl(): string {
  if (!API_URL || API_URL.includes('SEU_ENDPOINT')) {
    throw new Error(
      'Configure VITE_API_URL no arquivo .env com a URL gerada pelo CrudCrud.',
    )
  }

  return API_URL
}

export const bookService = {
  async list(): Promise<Book[]> {
    const response = await axios.get<Book[]>(ensureApiUrl())
    return response.data
  },

  async create(book: NewBook): Promise<Book> {
    const response = await axios.post<Book>(ensureApiUrl(), book)
    return response.data
  },

  async remove(id: string): Promise<void> {
    await axios.delete(`${ensureApiUrl()}/${id}`)
  },

  async updateStatus(book: Book): Promise<Book> {
    const updatedBook: NewBook = {
      title: book.title,
      author: book.author,
      status: book.status === 'Lido' ? 'Não lido' : 'Lido',
    }

    await axios.put(`${ensureApiUrl()}/${book._id}`, updatedBook)
    return { ...book, status: updatedBook.status }
  },
}
