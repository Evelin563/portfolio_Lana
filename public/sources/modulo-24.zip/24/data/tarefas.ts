export type Tarefa = {
  id: number;
  titulo: string;
};

const tarefasIniciais: Tarefa[] = [
  { id: 1, titulo: 'Revisar os conceitos de Server Components' },
  { id: 2, titulo: 'Escrever o primeiro teste unitário' },
  { id: 3, titulo: 'Celebrar cada pequena conquista' }
];

/** Simula a consulta a uma API sem depender de serviço externo. */
export async function buscarTarefas(): Promise<Tarefa[]> {
  return Promise.resolve(tarefasIniciais);
}
