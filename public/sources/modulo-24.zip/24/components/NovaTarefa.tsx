'use client';

import { FormEvent, useState } from 'react';

type NovaTarefaProps = {
  aoAdicionar: (titulo: string) => void;
};

export default function NovaTarefa({ aoAdicionar }: NovaTarefaProps) {
  const [titulo, setTitulo] = useState('');
  const [erro, setErro] = useState('');

  function enviar(evento: FormEvent<HTMLFormElement>) {
    evento.preventDefault();
    const tituloFormatado = titulo.trim();

    if (!tituloFormatado) {
      setErro('Digite uma tarefa antes de adicionar.');
      return;
    }

    aoAdicionar(tituloFormatado);
    setTitulo('');
    setErro('');
  }

  return (
    <form className="nova-tarefa" onSubmit={enviar} noValidate>
      <label htmlFor="titulo">Qual é a sua próxima tarefa?</label>
      <div className="campo-grupo">
        <input id="titulo" name="titulo" value={titulo} onChange={(evento) => setTitulo(evento.target.value)} placeholder="Ex.: Estudar testes com Jest" aria-describedby="erro-titulo" />
        <button type="submit">Adicionar tarefa</button>
      </div>
      {erro && <p id="erro-titulo" role="alert">{erro}</p>}
    </form>
  );
}
