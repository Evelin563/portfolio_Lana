'use client';

import { useState } from 'react';
import NovaTarefa from '@/components/NovaTarefa';
import { useContadorDeTarefas } from '@/hooks/useContadorDeTarefas';
import type { Tarefa } from '@/data/tarefas';

export default function PainelDeTarefas({ tarefasIniciais }: { tarefasIniciais: Tarefa[] }) {
  const [tarefas, setTarefas] = useState(tarefasIniciais);
  const quantidade = useContadorDeTarefas(tarefas);

  function adicionarTarefa(titulo: string) {
    setTarefas((atuais) => [...atuais, { id: Date.now(), titulo }]);
  }

  return (
    <section className="painel" aria-labelledby="lista-title">
      <div className="painel-cabecalho">
        <div><p className="sobretitulo">MEU PLANEJAMENTO</p><h2 id="lista-title">Tarefas da semana</h2></div>
        <span className="contador" aria-label={`${quantidade} tarefas`}>{quantidade}</span>
      </div>
      <ul className="lista-tarefas">
        {tarefas.map((tarefa, indice) => <li key={tarefa.id}><span>{String(indice + 1).padStart(2, '0')}</span>{tarefa.titulo}</li>)}
      </ul>
      <NovaTarefa aoAdicionar={adicionarTarefa} />
    </section>
  );
}
