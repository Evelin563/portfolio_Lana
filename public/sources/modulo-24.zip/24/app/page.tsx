import PainelDeTarefas from '@/components/PainelDeTarefas';
import { buscarTarefas } from '@/data/tarefas';

/** Server Component: carrega os dados antes de entregar a interface ao cliente. */
export default async function Page() {
  const tarefas = await buscarTarefas();

  return (
    <main>
      <section className="apresentacao">
        <p className="marca"><span>✦</span> BLOOM LIST</p>
        <h1>Um dia de cada vez,<br /><em>com carinho.</em></h1>
        <p className="introducao">Organize suas pequenas grandes ideias. Adicione uma tarefa e acompanhe o que floresce hoje.</p>
      </section>
      <PainelDeTarefas tarefasIniciais={tarefas} />
      <footer>Feito para aprender Next.js, React e testes unitários ✿</footer>
    </main>
  );
}
