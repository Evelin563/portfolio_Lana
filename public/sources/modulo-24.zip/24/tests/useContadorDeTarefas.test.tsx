import { renderHook } from '@testing-library/react';
import { useContadorDeTarefas } from '@/hooks/useContadorDeTarefas';

describe('useContadorDeTarefas', () => {
  it('retorna a quantidade de tarefas recebida', () => {
    const { result, rerender } = renderHook(({ tarefas }) => useContadorDeTarefas(tarefas), {
      initialProps: { tarefas: [{ id: 1, titulo: 'Uma' }, { id: 2, titulo: 'Duas' }] }
    });
    expect(result.current).toBe(2);
    rerender({ tarefas: [{ id: 1, titulo: 'Uma' }] });
    expect(result.current).toBe(1);
  });
});
