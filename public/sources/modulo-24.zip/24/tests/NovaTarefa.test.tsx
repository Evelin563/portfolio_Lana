import { fireEvent, render, screen } from '@testing-library/react';
import NovaTarefa from '@/components/NovaTarefa';

describe('<NovaTarefa />', () => {
  it('renderiza o campo e o botão', () => {
    render(<NovaTarefa aoAdicionar={jest.fn()} />);
    expect(screen.getByLabelText('Qual é a sua próxima tarefa?')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Adicionar tarefa' })).toBeInTheDocument();
  });

  it('mostra uma mensagem ao submeter uma tarefa vazia', () => {
    render(<NovaTarefa aoAdicionar={jest.fn()} />);
    fireEvent.click(screen.getByRole('button', { name: 'Adicionar tarefa' }));
    expect(screen.getByRole('alert')).toHaveTextContent('Digite uma tarefa antes de adicionar.');
  });

  it('envia a tarefa preenchida e limpa o campo', () => {
    const aoAdicionar = jest.fn();
    render(<NovaTarefa aoAdicionar={aoAdicionar} />);
    const campo = screen.getByLabelText('Qual é a sua próxima tarefa?');
    fireEvent.change(campo, { target: { value: '  Testar o formulário  ' } });
    fireEvent.click(screen.getByRole('button', { name: 'Adicionar tarefa' }));
    expect(aoAdicionar).toHaveBeenCalledWith('Testar o formulário');
    expect(campo).toHaveValue('');
  });
});
