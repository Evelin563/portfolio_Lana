# Bloom List — testes unitários em Next.js 15

Projeto prático de uma lista de tarefas com **Next.js 15**, App Router, TypeScript, Jest e Testing Library.

## Funcionalidades

- `app/page.tsx` é um Server Component e busca tarefas de um arquivo local assíncrono.
- `components/NovaTarefa.tsx` é um Client Component com formulário controlado e validação.
- `hooks/useContadorDeTarefas.ts` retorna a quantidade atual de tarefas.
- O painel atualiza a lista e o contador sem recarregar a página.

## Executar localmente

```bash
npm install
npm run dev
```

Abra `http://localhost:3000`.

## Testes

```bash
npm test
npm run test:coverage
```

Os testes cobrem o formulário `NovaTarefa`, o hook isolado com `renderHook` e a renderização da página com as tarefas locais, sem mock de API externa.
